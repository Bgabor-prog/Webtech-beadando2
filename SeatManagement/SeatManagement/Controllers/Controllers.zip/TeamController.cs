﻿using System.Linq;
using DataAccess;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeatManagement.Table;


namespace SeatManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TeamController : ControllerBase
    {

        private readonly ILogger<TeamController> _logger;
        private readonly SeatManagementContext _ctx;

        public TeamController(ILogger<TeamController> logger, SeatManagementContext ctx)
        {
            _logger = logger;
            _ctx = ctx;

        }

        [Authorize]
        [HttpGet("/api/Team/GetNames")]
        public ActionResult GetNames()
        {
            return Ok(_ctx.Team.Select(item => item.Name));
        }

        [Authorize]
        [HttpGet("/api/Team")]
        public ActionResult<Team> GetTeam(string teamName)
        {
            if (string.IsNullOrEmpty(teamName))
            {
                return BadRequest("Team Name should not be empty or null.");
            }
            if (!_ctx.Team.Where(item => item.Name == teamName).Any())
            {
                return BadRequest($"Team '{teamName}' not exists.");
            }

            Team result = _ctx.Team.Include();

            //result.Rooms.Add(_ctx.Team.Where(item => item.Name == teamName).SelectMany(r => r.Rooms).FirstOrDefault());

            //var query = _ctx.Team.Include("Rooms").Select(item => _ctx.Room.Any(room => room.Name == teamName));



            return Ok(query);
        }

        [Authorize]
        [HttpPost("/api/Team")]
        public ActionResult InsertUpdate(string teamName, [FromBody] Team team)
        {

            if (string.IsNullOrEmpty(team.Name))
            {
                return BadRequest("Team Name should be filled.");
            }

            Team teamR = _ctx.Team.FirstOrDefault(item => item.Name == teamName);
            if (teamR != null)
            {
                teamR.Name = team.Name;
                teamR.Manager = team.Manager;
                teamR.TMdeputy = team.Manager;
                teamR.ColorCode = team.ColorCode;
            }
            else
            {
                _ctx.Team.Add(team);
            }

            _ctx.SaveChanges();

            return Ok();
        }

        [Authorize]
        [HttpDelete("/api/Team")]
        public ActionResult Delete(string teamName)
        {
            if (string.IsNullOrEmpty(teamName))
            {
                return BadRequest("Team Name should be given.");
            }

            Team team = _ctx.Team.FirstOrDefault(item => item.Name == teamName);
            if (team == null)
            {
                return BadRequest("The data record is not exists.");
            }

            _ctx.Team.Remove(team);

            _ctx.SaveChanges();

            return Ok();
        }
    }
}
