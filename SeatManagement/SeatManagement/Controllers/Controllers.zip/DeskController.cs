﻿using DataAccess;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeatManagement.Table;
using System.Linq;

namespace SeatManagement.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class DeskController : ControllerBase
    {
        private readonly ILogger<DeskController> _logger;
        private readonly SeatManagementContext _ctx;

        public DeskController(ILogger<DeskController> logger, SeatManagementContext ctx)
        {
            _logger = logger;
            _ctx = ctx;

        }

        [Authorize]
        [HttpGet]
        public ActionResult GetDeskBy(string assetId)
        {
        
            if (!_ctx.Desk.Where(item => item.AssetId == assetId).Any())
            {
                return BadRequest($"Team '{assetId}' not exists.");
            }

            if (string.IsNullOrEmpty(assetId))
            {
                return BadRequest($"{assetId} not found");
            }

            //Desk result = _ctx.Desk.FirstOrDefault(item => item.AssetId == assetId);

            //result.Seat.Add(_ctx.Desk.Where(item => item.AssetId == assetId).Select(s => s.Seat).FirstOrDefault());

            var result = _ctx.Desk.Include("Seat").FirstOrDefault(action => _ctx.Seat.Any(user => user.Id == action.Id));

            return Ok(result);


        }

        [Authorize]
        [HttpPost]
        public ActionResult InsertDesk([FromBody] Desk desk)
        {
            if (_ctx.Desk.Where(item => item.AssetId == desk.AssetId).Any())
            {
                return BadRequest($"{desk.AssetId} already inserted");
            }
            else
            {
                _ctx.Desk.Add(desk);
                _ctx.SaveChanges();
                return Ok();
            }
        }
    }
}
